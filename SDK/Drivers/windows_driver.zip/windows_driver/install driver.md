##### Installing USB driver
-  Connect the camera to the computer,Open `device manager` on your computer, the device `Movidius MyriadX` can be seen.

- Open `windows command line`,run `moviUsbBoot.exe fw/flicRefApp.mvcmd` to boot device, `VSC loopback device` appears in `device manager`
- Open `device manager` on your computer,Update driver for `VSC loopback device` to `MovidiusDriver`,==Note:==
The `MovidiusDriver` driver package is provided in our `openncc` package

- If you are running multiple devices at the same time, you need to install `MovidiusDriver` for each device